# FollowFlow – Instrukcja uruchomienia

## Co masz w paczce
- `followers-landing.html` – strona dla klientów
- `server.js` – backend (płatności + maile)
- `package.json` – lista bibliotek

---

## Krok 1 – Załóż konto Resend (darmowe maile)

1. Wejdź na **resend.com** → zarejestruj się
2. Wejdź w **API Keys** → "Create API Key"
3. Skopiuj klucz `re_...` – będzie potrzebny za chwilę

---

## Krok 2 – Wrzuć projekt na Railway

1. Wejdź na **railway.app** → zaloguj się przez GitHub
2. Kliknij **"New Project" → "Deploy from GitHub repo"**
   - Lub: **"New Project" → "Empty project"** → wgraj pliki ręcznie
3. Po wgraniu wejdź w **Variables** i dodaj:

| Nazwa zmiennej | Wartość |
|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` (Twój Secret Key ze Stripe) |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` (patrz Krok 3) |
| `RESEND_API_KEY` | `re_...` (z Resend) |

---

## Krok 3 – Skonfiguruj Webhook w Stripe

1. Stripe → **Developers → Webhooks → "Add endpoint"**
2. URL: `https://TWOJA-DOMENA.railway.app/webhook`
3. Zdarzenie: `payment_intent.succeeded`
4. Skopiuj **Signing secret** (`whsec_...`) → wklej do Railway jako `STRIPE_WEBHOOK_SECRET`

---

## Krok 4 – Wrzuć stronę HTML

1. W projekcie Railway utwórz folder **`public/`**
2. Wrzuć do niego plik `followers-landing.html` i zmień nazwę na **`index.html`**
3. W pliku podmień adres backendu – znajdź `https://TWOJA_DOMENA` i wstaw adres Railway

---

## Gotowe! ✅

Od teraz gdy klient zapłaci → dostajesz maila na FollowFlowSupport@proton.me z:
- nickiem klienta
- platformą (IG/TT)
- pakietem i ilością
- kwotą

